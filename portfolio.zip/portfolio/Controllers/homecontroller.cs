using Microsoft.AspNetCore.Mvc;
namespace portfolio.Controllers     //be sure to use your own project's namespace!
{
    public class homecontroller : Controller   //remember inheritance??
    {

        [HttpGet] 
        [Route("")]    
        public string Index()
        {
            return "This is my Index!";
        }
        [HttpGet] 
        [Route("projects")]    
        public string Projects()
        {
            return "These are my Projects!";
        }
        [HttpGet] 
        [Route("contacts")]    
        public string Contacts()
        {
            return "These are my Contacts!";
        }        


    }
}