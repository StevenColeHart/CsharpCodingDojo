﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace beltexam.Migrations
{
    public partial class forth : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Like_User_useridUser",
                table: "Like");

            migrationBuilder.DropForeignKey(
                name: "FK_Post_User_creatoridUser",
                table: "Post");

            migrationBuilder.RenameColumn(
                name: "idUser",
                table: "User",
                newName: "UserId");

            migrationBuilder.RenameColumn(
                name: "creatoridUser",
                table: "Post",
                newName: "creatorUserId");

            migrationBuilder.RenameIndex(
                name: "IX_Post_creatoridUser",
                table: "Post",
                newName: "IX_Post_creatorUserId");

            migrationBuilder.RenameColumn(
                name: "useridUser",
                table: "Like",
                newName: "UserId");

            migrationBuilder.RenameIndex(
                name: "IX_Like_useridUser",
                table: "Like",
                newName: "IX_Like_UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Like_User_UserId",
                table: "Like",
                column: "UserId",
                principalTable: "User",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Post_User_creatorUserId",
                table: "Post",
                column: "creatorUserId",
                principalTable: "User",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Like_User_UserId",
                table: "Like");

            migrationBuilder.DropForeignKey(
                name: "FK_Post_User_creatorUserId",
                table: "Post");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "User",
                newName: "idUser");

            migrationBuilder.RenameColumn(
                name: "creatorUserId",
                table: "Post",
                newName: "creatoridUser");

            migrationBuilder.RenameIndex(
                name: "IX_Post_creatorUserId",
                table: "Post",
                newName: "IX_Post_creatoridUser");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "Like",
                newName: "useridUser");

            migrationBuilder.RenameIndex(
                name: "IX_Like_UserId",
                table: "Like",
                newName: "IX_Like_useridUser");

            migrationBuilder.AddForeignKey(
                name: "FK_Like_User_useridUser",
                table: "Like",
                column: "useridUser",
                principalTable: "User",
                principalColumn: "idUser",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Post_User_creatoridUser",
                table: "Post",
                column: "creatoridUser",
                principalTable: "User",
                principalColumn: "idUser",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
