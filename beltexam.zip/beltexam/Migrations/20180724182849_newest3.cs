﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace beltexam.Migrations
{
    public partial class newest3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Like_User_userid",
                table: "Like");

            migrationBuilder.DropForeignKey(
                name: "FK_Post_User_creatorid",
                table: "Post");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "User",
                newName: "UserId");

            migrationBuilder.RenameColumn(
                name: "creatorid",
                table: "Post",
                newName: "creatorUserId");

            migrationBuilder.RenameIndex(
                name: "IX_Post_creatorid",
                table: "Post",
                newName: "IX_Post_creatorUserId");

            migrationBuilder.RenameColumn(
                name: "userid",
                table: "Like",
                newName: "UserId");

            migrationBuilder.RenameIndex(
                name: "IX_Like_userid",
                table: "Like",
                newName: "IX_Like_UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Like_User_UserId",
                table: "Like",
                column: "UserId",
                principalTable: "User",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Post_User_creatorUserId",
                table: "Post",
                column: "creatorUserId",
                principalTable: "User",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Like_User_UserId",
                table: "Like");

            migrationBuilder.DropForeignKey(
                name: "FK_Post_User_creatorUserId",
                table: "Post");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "User",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "creatorUserId",
                table: "Post",
                newName: "creatorid");

            migrationBuilder.RenameIndex(
                name: "IX_Post_creatorUserId",
                table: "Post",
                newName: "IX_Post_creatorid");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "Like",
                newName: "userid");

            migrationBuilder.RenameIndex(
                name: "IX_Like_UserId",
                table: "Like",
                newName: "IX_Like_userid");

            migrationBuilder.AddForeignKey(
                name: "FK_Like_User_userid",
                table: "Like",
                column: "userid",
                principalTable: "User",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Post_User_creatorid",
                table: "Post",
                column: "creatorid",
                principalTable: "User",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
