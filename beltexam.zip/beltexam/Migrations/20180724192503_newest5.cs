﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace beltexam.Migrations
{
    public partial class newest5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Like_User_UserId",
                table: "Like");

            migrationBuilder.DropForeignKey(
                name: "FK_Post_User_creatorUserId",
                table: "Post");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "User",
                newName: "UserID");

            migrationBuilder.RenameColumn(
                name: "creatorUserId",
                table: "Post",
                newName: "creatorUserID");

            migrationBuilder.RenameIndex(
                name: "IX_Post_creatorUserId",
                table: "Post",
                newName: "IX_Post_creatorUserID");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "Like",
                newName: "UserID");

            migrationBuilder.RenameIndex(
                name: "IX_Like_UserId",
                table: "Like",
                newName: "IX_Like_UserID");

            migrationBuilder.AddForeignKey(
                name: "FK_Like_User_UserID",
                table: "Like",
                column: "UserID",
                principalTable: "User",
                principalColumn: "UserID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Post_User_creatorUserID",
                table: "Post",
                column: "creatorUserID",
                principalTable: "User",
                principalColumn: "UserID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Like_User_UserID",
                table: "Like");

            migrationBuilder.DropForeignKey(
                name: "FK_Post_User_creatorUserID",
                table: "Post");

            migrationBuilder.RenameColumn(
                name: "UserID",
                table: "User",
                newName: "UserId");

            migrationBuilder.RenameColumn(
                name: "creatorUserID",
                table: "Post",
                newName: "creatorUserId");

            migrationBuilder.RenameIndex(
                name: "IX_Post_creatorUserID",
                table: "Post",
                newName: "IX_Post_creatorUserId");

            migrationBuilder.RenameColumn(
                name: "UserID",
                table: "Like",
                newName: "UserId");

            migrationBuilder.RenameIndex(
                name: "IX_Like_UserID",
                table: "Like",
                newName: "IX_Like_UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Like_User_UserId",
                table: "Like",
                column: "UserId",
                principalTable: "User",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Post_User_creatorUserId",
                table: "Post",
                column: "creatorUserId",
                principalTable: "User",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
