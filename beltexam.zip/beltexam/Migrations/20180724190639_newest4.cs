﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace beltexam.Migrations
{
    public partial class newest4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Like_Post_postid",
                table: "Like");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "Post",
                newName: "PostId");

            migrationBuilder.RenameColumn(
                name: "postid",
                table: "Like",
                newName: "PostId");

            migrationBuilder.RenameIndex(
                name: "IX_Like_postid",
                table: "Like",
                newName: "IX_Like_PostId");

            migrationBuilder.AddForeignKey(
                name: "FK_Like_Post_PostId",
                table: "Like",
                column: "PostId",
                principalTable: "Post",
                principalColumn: "PostId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Like_Post_PostId",
                table: "Like");

            migrationBuilder.RenameColumn(
                name: "PostId",
                table: "Post",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "PostId",
                table: "Like",
                newName: "postid");

            migrationBuilder.RenameIndex(
                name: "IX_Like_PostId",
                table: "Like",
                newName: "IX_Like_postid");

            migrationBuilder.AddForeignKey(
                name: "FK_Like_Post_postid",
                table: "Like",
                column: "postid",
                principalTable: "Post",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
