﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace beltexam.Migrations
{
    public partial class newest1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Like_Post_Postid",
                table: "Like");

            migrationBuilder.DropForeignKey(
                name: "FK_Like_User_UserId",
                table: "Like");

            migrationBuilder.DropForeignKey(
                name: "FK_Post_User_creatorUserId",
                table: "Post");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "User",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "creatorUserId",
                table: "Post",
                newName: "creatorid");

            migrationBuilder.RenameColumn(
                name: "Postid",
                table: "Post",
                newName: "id");

            migrationBuilder.RenameIndex(
                name: "IX_Post_creatorUserId",
                table: "Post",
                newName: "IX_Post_creatorid");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "Like",
                newName: "userid");

            migrationBuilder.RenameColumn(
                name: "Postid",
                table: "Like",
                newName: "postid");

            migrationBuilder.RenameIndex(
                name: "IX_Like_UserId",
                table: "Like",
                newName: "IX_Like_userid");

            migrationBuilder.RenameIndex(
                name: "IX_Like_Postid",
                table: "Like",
                newName: "IX_Like_postid");

            migrationBuilder.AddForeignKey(
                name: "FK_Like_Post_postid",
                table: "Like",
                column: "postid",
                principalTable: "Post",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Like_User_userid",
                table: "Like",
                column: "userid",
                principalTable: "User",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Post_User_creatorid",
                table: "Post",
                column: "creatorid",
                principalTable: "User",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Like_Post_postid",
                table: "Like");

            migrationBuilder.DropForeignKey(
                name: "FK_Like_User_userid",
                table: "Like");

            migrationBuilder.DropForeignKey(
                name: "FK_Post_User_creatorid",
                table: "Post");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "User",
                newName: "UserId");

            migrationBuilder.RenameColumn(
                name: "creatorid",
                table: "Post",
                newName: "creatorUserId");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "Post",
                newName: "Postid");

            migrationBuilder.RenameIndex(
                name: "IX_Post_creatorid",
                table: "Post",
                newName: "IX_Post_creatorUserId");

            migrationBuilder.RenameColumn(
                name: "userid",
                table: "Like",
                newName: "UserId");

            migrationBuilder.RenameColumn(
                name: "postid",
                table: "Like",
                newName: "Postid");

            migrationBuilder.RenameIndex(
                name: "IX_Like_userid",
                table: "Like",
                newName: "IX_Like_UserId");

            migrationBuilder.RenameIndex(
                name: "IX_Like_postid",
                table: "Like",
                newName: "IX_Like_Postid");

            migrationBuilder.AddForeignKey(
                name: "FK_Like_Post_Postid",
                table: "Like",
                column: "Postid",
                principalTable: "Post",
                principalColumn: "Postid",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Like_User_UserId",
                table: "Like",
                column: "UserId",
                principalTable: "User",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Post_User_creatorUserId",
                table: "Post",
                column: "creatorUserId",
                principalTable: "User",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
